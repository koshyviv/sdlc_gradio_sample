Here's a comprehensive codebase structure for the EMR User Management System based on the provided technical design. This structure includes the complete directory layout, main code files, configuration files, test cases, and documentation.

### 1. Directory Structure

```
/emr-user-management
├── /client                       # Frontend React application
│   ├── /public                   # Public static files
│   ├── /src
│   │   ├── /components           # React components
│   │   │   ├── Login.tsx
│   │   │   ├── UserManagement.tsx
│   │   ├── /redux                # Redux state management
│   │   │   ├── store.ts
│   │   │   ├── userSlice.ts
│   │   ├── /services             # API service calls
│   │   │   ├── UserService.ts
│   │   ├── /styles               # Global styles
│   │   ├── App.tsx               # Main application component
│   │   ├── index.tsx             # Entry point
│   ├── package.json              # Frontend dependencies
│   ├── tsconfig.json             # TypeScript configuration
│   ├── .env                      # Environment variables
│   
├── /server                       # Backend Node.js application
│   ├── /config                   # Configuration files
│   │   ├── dbConfig.js          # Database configuration
│   │   ├── serverConfig.js       # Server configuration
│   ├── /controllers              # Business logic controllers
│   │   ├── authController.js
│   │   ├── userController.js
│   ├── /middlewares              # Middleware functions
│   │   ├── authMiddleware.js
│   ├── /models                   # Database models
│   │   ├── userModel.js
│   ├── /routes                   # API routes
│   │   ├── authRoutes.js
│   │   ├── userRoutes.js
│   ├── /tests                    # Test cases
│   │   ├── auth.test.js
│   │   ├── user.test.js
│   ├── app.js                    # Main application entry point
│   ├── package.json              # Backend dependencies
│   ├── .env                      # Environment variables
│   ├── knexfile.js               # Knex configuration for database migrations
│
├── /docs                         # Documentation
│   ├── architecture.md           # Architecture overview
│   ├── api_specification.md      # API endpoints specification
│   ├── setup_guide.md            # Setup and installation guide
│
└── README.md                     # Project overview and instructions
```

### 2. Main Code Files

#### Frontend Code (React)
- **Login Component (`src/components/Login.tsx`)**
```tsx
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login } from '../redux/userSlice';
import { TextField, Button, CircularProgress } from '@mui/material';

const Login = ({ onLogin, errorMessage }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const dispatch = useDispatch();

    const handleChange = (event) => {
        const { name, value } = event.target;
        if (name === "username") setUsername(value);
        if (name === "password") setPassword(value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        try {
            const token = await dispatch(login({ username, password }));
            onLogin(token);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <TextField name="username" label="Username" onChange={handleChange} required />
            <TextField name="password" type="password" label="Password" onChange={handleChange} required />
            <Button type="submit" disabled={loading}>
                {loading ? <CircularProgress size={24} /> : 'Login'}
            </Button>
            {errorMessage && <p>{errorMessage}</p>}
        </form>
    );
};

export default Login;
```

- **User Management Component (`src/components/UserManagement.tsx`)**
```tsx
import React, { useState } from 'react';
import { Button, TextField, CircularProgress, List } from '@mui/material';

const UserManagement = ({ users, onAddUser, onUpdateUser, onDeleteUser }) => {
    const [newUser, setNewUser] = useState({ username: '', role: '' });
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        setNewUser({ ...newUser, [e.target.name]: e.target.value });
    };

    const handleAddUser = async () => {
        setLoading(true);
        await onAddUser(newUser);
        setLoading(false);
        setNewUser({ username: '', role: '' });
    };

    return (
        <div>
            <TextField name="username" label="Username" value={newUser.username} onChange={handleChange} />
            <TextField name="role" label="Role" value={newUser.role} onChange={handleChange} />
            <Button onClick={handleAddUser} disabled={loading}>
                {loading ? <CircularProgress size={24} /> : 'Add User'}
            </Button>
            <List>
                {users.map(user => (
                    <li key={user.id}>
                        {user.username} - {user.role}
                        <Button onClick={() => onUpdateUser(user.id)}>Edit</Button>
                        <Button onClick={() => onDeleteUser(user.id)}>Delete</Button>
                    </li>
                ))}
            </List>
        </div>
    );
};

export default UserManagement;
```

#### Backend Code (Node.js)
- **Authentication Controller (`server/controllers/authController.js`)**
```javascript
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const UserModel = require('../models/userModel');

exports.login = async (req, res) => {
    const { username, password } = req.body;
    const user = await UserModel.findByUsername(username);
    if (!user) return res.status(401).send('Invalid credentials');

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) return res.status(401).send('Invalid credentials');

    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    return res.json({ token });
};

exports.logout = (req, res) => {
    // Invalidate JWT session logic (handled on client)
    return res.status(204).send();
};
```

- **User Management Controller (`server/controllers/userController.js`)**
```javascript
const UserModel = require('../models/userModel');

exports.getUsers = async (req, res) => {
    const users = await UserModel.findAll();
    res.json(users);
};

exports.addUser = async (req, res) => {
    const { username, password, role } = req.body;
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await UserModel.create({ username, password_hash: passwordHash, role });
    res.status(201).json({ id: user.id, username: user.username, role: user.role });
};

exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { username, role,